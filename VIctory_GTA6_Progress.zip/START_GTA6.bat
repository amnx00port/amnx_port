@echo off
title GTA VI - VIctory
echo.
echo  ============================================================
echo   GTA VI - Xbox Series X Master Build 1.0.2.1
echo   VIctory Emulator
echo  ============================================================
echo.

set "VICTORY_D3D12_DRED=0"
set "VICTORY_D3D12_DEBUG=0"
set "VICTORY_SHADER_LOOP_LIMIT=16"
set "VICTORY_PIPELINE_BUDGET_MS=120"
set "VICTORY_LOG=warn"
set "RUST_LOG=warn"
set "VICTORY_PLANE=1"
set "VICTORY_PLANE_AUTO=1"
set "VICTORY_DEVICE_RECOVER=1"
set "VICTORY_COPY_MODE=none"
set "VICTORY_REFRESH_ONCE=1"
set "VICTORY_SAFE_COMPUTE=1"
set "VICTORY_MAX_DRAWS=0"
set "VICTORY_GPU_TIMEOUT_MS=3000"
set "VICTORY_LISTS_PER_GROUP=4"

echo Launching...
"C:\gems\VIctory\VIctory-main\target\release\victory.exe" run "c:\gems\gta live\GTA6.Xbox.v1.0.2.1\game_scarlett_master.exe" --execute

echo.
echo Done. Code: %ERRORLEVEL%
pause
