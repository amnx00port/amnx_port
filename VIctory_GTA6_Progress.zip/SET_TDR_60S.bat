@echo off
echo ================================================================
echo   УВАГА: Цей скрипт змінює GPU watchdog timeout Windows
echo   Запусти від АДМІНІСТРАТОРА (ПКМ → "Запустити від імені адміністратора")
echo ================================================================
echo.
reg add "HKLM\System\CurrentControlSet\Control\GraphicsDrivers" /v TdrDelay /t REG_DWORD /d 60 /f
reg add "HKLM\System\CurrentControlSet\Control\GraphicsDrivers" /v TdrDdiDelay /t REG_DWORD /d 60 /f
reg add "HKLM\System\CurrentControlSet\Control\GraphicsDrivers" /v TdrLimitTime /t REG_DWORD /d 60 /f
echo.
echo [OK] TdrDelay = 60 секунд встановлено!
echo [!] ПОТРІБНО ПЕРЕЗАВАНТАЖИТИ ПК щоб набрало ефект
echo.
pause
